package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.demo.models.Autor;
import com.example.demo.models.Livro;
import com.example.demo.repositories.AutorRepository;
import com.example.demo.repositories.LivroRepository;

@SpringBootApplication
public class DemoApplication {

    @Bean
    public CommandLineRunner init(
        @Autowired LivroRepository livroRepository,
        @Autowired AutorRepository autorRepository
    ) {
        return args -> {
            Autor autor1 = autorRepository.save(new Autor(null, "George Orwell"));
            Autor autor2 = autorRepository.save(new Autor(null, "Isaac Asimov"));

            Livro livro1 = livroRepository.save(new Livro(null, "1984", 45.90));
            Livro livro2 = livroRepository.save(new Livro(null, "Animal Farm", 35.90));
            Livro livro3 = livroRepository.save(new Livro(null, "Foundation", 55.90));

            autor1.addLivro(livro1);
            autor1.addLivro(livro2);
            autor2.addLivro(livro3);
            autorRepository.save(autor1);
            autorRepository.save(autor2);

            List<Autor> autores = autorRepository.findByNomeStartingWith("G");
            System.out.println("Autores com 'G':");
            for (Autor autor : autores) {
                System.out.println(autor.getNome());
            }

            System.out.println("Autor específico pelo ID: '1' ");
            Autor autor = autorRepository.findByIdWithLivros(1L);
            System.out.println("Autor: " + autor.getNome() + " e seus livros:");
        

            List<Livro> livros1 = livroRepository.findByPrecoLessThanEqual(40.00);
            System.out.println("Livros com preço menor ou igual a R$40,00:");
            for (Livro livrofor1 : livros1) {
                System.out.println(livrofor1.getTitulo());
            }

            List<Livro> livros2 = livroRepository.findByPrecoGreaterThan(40.00);
            System.out.println("Livros com preço maior que R$40,00:");
            for (Livro livrofor2 : livros2) {
                System.out.println(livrofor2.getTitulo());
            }

            List<Livro> livros3 = livroRepository.findByTituloStartingWith("A");
            System.out.println("Livros com título começando com 'A':");
            for (Livro livrofor3 : livros3) {
                System.out.println(livrofor3.getTitulo());
            }
        };
    }

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }
}